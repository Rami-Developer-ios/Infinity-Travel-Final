export PATH=$HOME/.swift-bin:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/.swift-lib
